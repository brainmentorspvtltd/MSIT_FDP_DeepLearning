import streamlit as st

st.title("This is streamlit demo...")
st.write("In this app we will classify chest xray as infected from covid or not")
import streamlit as st
import os
import cv2
from PIL import Image
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense

def loadImage(img_file):
    img = Image.open(img_file)
    return img

img_upload = st.file_uploader("Upload XRay Image :", type=["png","jpeg","jpg"])

if img_upload is not None:
    img = loadImage(img_upload)
    st.image(img)
    with open(os.path.join("test_images", img_upload.name), "wb") as f:
        f.write(img_upload.getbuffer())
    
    with st.form("my_form"):
        submit_btn = st.form_submit_button("Predict")
        if submit_btn:
            img = cv2.imread("test_images/"+img_upload.name)
            img = cv2.resize(img, (100,100))
            img = img / 255.0
            img = np.reshape(img, (1, 100, 100, 3))
            model = Sequential([
                        Conv2D(32, 3, input_shape=(100,100,3), activation='relu'),
                        MaxPooling2D(),
                        Conv2D(16, 3, activation='relu'),
                        MaxPooling2D(),
                        Conv2D(16, 3, activation='relu'),
                        MaxPooling2D(),
                        Flatten(),
                        Dense(512, activation='relu'),
                        Dense(256, activation='relu'),
                        Dense(1, activation='sigmoid')
                    ])
            checkpoint_path = "checkpoint/cp.ckpt"
            checkpoint_dir = os.path.dirname(checkpoint_path)

            model.load_weights(checkpoint_path)
            arr = model.predict(img)
            # print("Prediction is",arr)
            pred = np.round(arr[0])
            if pred == 0:
                st.write("Not Infected...")
            else:
                st.write("Infected...")

